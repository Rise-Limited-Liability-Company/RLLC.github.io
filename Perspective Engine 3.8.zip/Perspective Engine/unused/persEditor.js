// Packages
const prompt = require('prompt-sync')({sigint:false})
const fs = require('fs')
const log = console.log

const persEditor = {
    version:1.0
    //,
    //group:0
    //,
    //groups:{}
    ,
    zero:{}
    ,
    one:{}
    ,
    two:{}
    ,
    three:{}
    ,
    four:{}
    ,
    five:{}
    ,
    six:{}
    ,
    seven:{}
    ,
    eight:{}
    ,
    nine:{}
    ,
    parse(command) {
        let tokens = ''
        let result
        if (command.search(' ')) {
            tokens = command.split(' ')
        }
        if (command == '') {
        }
        if (tokens[0] == 'get' && tokens[1] == 'editor') {
            result = `Pers Editor ${persEditor}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'version') {
            result = `Pers Editor ${this.version.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'zero') {
            result = `Pers Editor ${this.zero.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'one') {
            result = `Pers Editor ${this.one.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'two') {
            result = `Pers Editor ${this.two.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'three') {
            result = `Pers Editor ${this.three.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'four') {
            result = `Pers Editor ${this.four.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'five') {
            result = `Pers Editor ${this.five.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'six') {
            result = `Pers Editor ${this.six.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'seven') {
            result = `Pers Editor ${this.seven.toString()}`
        } 
        if (tokens[0] == 'get' && tokens[1] == 'eight') {
            result = `Pers Editor ${this.eight.toString()}`
        }
        if (tokens[0] == 'get' && tokens[1] == 'nine') {
            result = `Pers Editor ${this.nine.toString()}`
        }
        if (tokens[0] == 'set' && tokens[1] == 'group' && tokens[2] && tokens[3] && tokens[4]) {
            if (tokens[2] == '0') {
                this.zero = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.zero
            }
            else if (tokens[2] == '1') {
                this.one = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.one
            }
            else if (tokens[2] == '2') {
                this.two = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.two
            }
            else if (tokens[2] == '3') {
                this.three = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.three
            }
            else if (tokens[2] == '4') {
                this.four = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.four
            }
            else if (tokens[2] == '5') {
                this.five = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.five
            }
            else if (tokens[2] == '6') {
                this.six = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.six
            }
            else if (tokens[2] == '7') {
                this.seven = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.seven
            }
            else if (tokens[2] == '8') {
                this.eight = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.eight
            }
            else if (tokens[2] == '9') {
                this.nine = {
                    first:tokens[3]
                    ,
                    second:tokens[4]
                }
                result = this.nine
            }
        }
        if (tokens[0] == 'compile') {
            result = `[0]\nfirst=${this.zero.first}\second=${this.zero.second}\n[1]\nfirst=${this.one.first}\second=${this.one.second}\n[2]\nfirst=${this.two.first}\second=${this.two.second}\n[3]\nfirst=${this.three.first}\second=${this.three.second}\n[4]\nfirst=${this.four.first}\second=${this.four.second}\n[5]\nfirst=${this.five.first}\second=${this.five.second}\n[6]\nfirst=${this.six.first}\second=${this.six.second}\n[7]\nfirst=${this.seven.first}\second=${this.seven.second}\n[8]\nfirst=${this.eight.first}\second=${this.eight.second}\n[9]\nfirst=${this.nine.first}\second=${this.nine.second}`
        } else {
            result = '>: Invalid Command'
        }
        return result
    }
    ,
    init() {
        const command = prompt('~: ')
        log(this.parse(command))
        this.init()
    }
}

log(`Pers Editor ${persEditor.version.toString()}`)
persEditor.init()